//
//  PopoverDetailViewController.h
//
//  Created by Shuichi Tsutsumi on 2014/09/14.
//  Modified by Patrick Murray on 20/4/15.
//  Copyright (c) 2014 Shuichi Tsutsumi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PopoverDetailViewController : UIViewController

@property (nonatomic, strong) UIImage *image;

@end
